package com.code.files.listener;

public interface OnItemClickLIstener {
        void onItemClick(int position);
    }